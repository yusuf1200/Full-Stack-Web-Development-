var assert = require("assert");
const request = require("request");
const axios = require("axios");


describe("Tour Radar Tests with Mocha", function () {
  describe("Test users", function () {
    describe("User authenticity", async function () {
      var myurl = "http://localhost:3000";
      it("Fail 1. Signup with invalid email", function () {
        var data = {
          email: "user1#gmail@com",
          password: "pass123",
        };
        request.post(
          {
            headers: { "content-type": "application/json" },
            url: myurl + "/signup",
            body: JSON.stringify(data),
          },
          function (error, response, body) {
            assert.strictEqual(response.data.message, "Signup Failed. Invalid email");
          }
        );
      });
      it("Fail 2. Sign up where password and confirm password doesn't match", function () {
        let data = {
          email: "user1@gmail.com",
          password: "pass123_#",
        };
        request.post(
          {
            headers: { "content-type": "application/json" },
            url: myurl + "/signup",
            body: JSON.stringify(data),
          },
          function (error, response, body) {
            assert.strictEqual(response.data.message, "User validation failed: passwordConfirm: Passwords are not the same!");
          }
        );
      });
      it("Success 1. Signing up", function () {
        let data = {
          email: "user1@gmail.com",
          password: "pass123",
          passwordConfirmed: "pass123"
        };
        request.post(
          {
            headers: { "content-type": "application/json" },
            url: myurl + "/signup",
            body: JSON.stringify(data),
          },
          function (error, response, body) {
            assert.strictEqual(response.data.message, "New user has successfully signed up");
          }
        );
      });
      it("Fail 3. Login with incorrect password", function () {
        let data = {
          email: "user1@gmail.com",
          password: "pass12345",
        };
        request.post(
          {
            headers: { "content-type": "application/json" },
            url: myurl + "/login",
            body: JSON.stringify(data),
          },
          function (error, response, body) {
            assert.strictEqual(response.data.message, "Incorrect email or password");
          }
        );
      });
      it("Fail 4. Login with incorrect email", function () {
        let data = {
          email: "user_no_exist@gmail.com",
          password: "pass1234",
        };
        request.post(
          {
            headers: { "content-type": "application/json" },
            url: myurl + "/login",
            body: JSON.stringify(data),
          },
          function (error, response, body) {
            assert.strictEqual(response.data.message, "Incorrect email or password");
          }
        );
      });
      it("Fail 5. GET - Login without Password", function () {
        let email = "user1@gmail.com";

        request.get(
          {
            headers: { "content-type": "application/json" },
            url: myurl + "/login",
          },
          function (error, response, body) {
            assert.strictEqual(response.data.message, "Please provide email and password!");
          }
        );
      });
      it("Fail 6. GET- Login without email", function () {
        let password = "password";
        request.put(
          {
            headers: { "content-type": "application/json" },
            url: myurl + "/login",
          },
          function (error, response, body) {
            assert.strictEqual(response.data.message, "Please provide email and password!");
          }
        );
      });


  
      it("Success 2. User logs in with valid email and password", function () {
        let data = {
          email: "user1@gmail.com",
          password: "pass123",
        };
        request.get(
          {
            headers: { "content-type": "application/json" },
            url: myurl + "/login",
            body: JSON.stringify(data),
          },
          function (error, response, body) {
            assert.strictEqual(response.data.message, "User has successfully logged in");
          }
        );
      });

   

    });
  });
});