var assert = require("assert");
const axios = require("axios");

let complete;
describe("Tour Radar Testing", function () {
  describe("Tour", async function () {
    var myurl = "http://localhost:3000";
    it("Success 1. POST - Valid tour", function () {
      var data = {
        id: 1,
        name: "St. John's to St. Anthony",
        duration: 7,
        maxGroupSize: 10,
        difficulty: 'easy',
        price: 999,
        summary: "Enjoy the beauty of Newfoundland",
        imageCover: 'nl.jpg'
      };
      complete = axios
        .post(myurl + "/api/v1/tours/", data, {
          headers: { "content-type": "application/json" },
        })
        .then((response) => {
          assert.strictEqual(
            response.data.message,
            "New tour has been added successfully."
          );
        });
    });

    it("Failure 1. POST - Tour without required field", function () {
      let data = {
        id: 1,
        name: "St. John to St. Anthony",
        maxGroupSize: 10,
        difficulty: 'easy',
        price: 999,
        summary: "Enjoy the beauty of Newfoundland",
        imageCover: 'nl.jpg'
      };
      if (complete) {
        axios
          .post(myurl + "/api/v1/tours/", data, {
            headers: { "content-type": "application/json" },
          })
          .then((response) => {
            assert.strictEqual(
              response.data.message,
              'A tour must have a duration'
            );
          });
      }
    });

    it("Success 2. Get - Valid tour", function () {
      let data = {
        id: 1,
        name: "St. John's to St. Anthony",
        duration: 7,
        maxGroupSize: 10,
        difficulty: 'easy',
        price: 999,
        summary: "Enjoy the beauty of Newfoundland",
        imageCover: 'nl.jpg'
      };
      axios
        .get(myurl + "/api/v1/tours/" + data.id, {
          headers: { "content-type": "application/json" },
        })
        .then((response) => {
          assert.strictEqual(response.data.name, data.name);
          assert.strictEqual(response.data.duration, data.duration);
          assert.strictEqual(response.data.id, data.id);
          assert.strictEqual(response.data.price, data.price);
          assert.strictEqual(response.data.summary, data.summary);
        });
    });

    it("Failure 2. Get - tour", function () {
      let data = {
        id: 1,
        name: "St. John's to St. Anthony",
        duration: 7,
        maxGroupSize: 10,
        difficulty: 'easy',
        price: 999,
        summary: "Enjoy the beauty of Newfoundland",
        imageCover: 'nl.jpg'
      };
      axios
        .get(myurl + "/api/v1/tours/" + data.id+5, {
          headers: { "content-type": "application/json" },
        })
        .then((response) => {
          assert.strictEqual(response.data.message, 'No tour found with that ID');
        });
    });


    it("Success 3. Delete - Valid Tour", function () {
      if (complete) {
        axios
          .delete(myurl + "/api/v1/tours/1", {
            headers: { "content-type": "application/json" },
          })
          .then((response) => {
            assert.strictEqual(
              response.data.message,
              "Tour deleted successfully"
            );
          });
      }
    });

    it("Failure 4. Delete - Invalid product", function () {
      if (complete) {
        axios
          .delete(myurl + "/api/v1/tours/1", {
            headers: { "content-type": "application/json" },
          })
          .then((response) => {
            assert.strictEqual(response.data.message, 'No tour found with that ID');
          });
      }
    });
  });
});