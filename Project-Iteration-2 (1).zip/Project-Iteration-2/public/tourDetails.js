$(document).ready(function(){
    $(".inner-column").hide();
    $("#del").hide();


    $("#searchButton").click(function(event){
        findTour();
    })

    $("#deleteButton").click(function(event){
        deleteTour();
    })



    function findTour(){
        let tourId=$("#tourID").val();
        $.ajax({
            url: '/api/v1/tours/'+tourId,
            type: 'GET',
            contentType: 'application/json',                        
            success: function(response){
                console.log(response)
                let name=response.data.tour.name;
                let photo=response.data.tour.imageCover;
                let summary=response.data.tour.summary;
                let des=response.data.tour.description;
                let location=response.data.tour.location;

                $("#photo").attr("src", photo);
                $("#location").html(location);
                $("#tourName").html(name);
                $("#summary").html(summary);
                $("#description").html(des);
                $(".inner-column").show();


                
    
                

            },
            // If there's an error, we can use the alert box to make sure we understand the problem
            error: function(xhr, status, error){
                var errorMessage = xhr.status + ': ' + xhr.statusText
                alert('Error - ' + errorMessage);
            }})

    }

    function deleteTour(){
        let tourId=$("#tourID").val();
        $.ajax({
            url: '/api/v1/tours/'+tourId,
            type: 'DELETE',
            contentType: 'application/json',                        
            success: function(response){
                $(".inner-column").hide();
                $("#del").show();
                
                
                
    
                

            },
            // If there's an error, we can use the alert box to make sure we understand the problem
            error: function(xhr, status, error){
                var errorMessage = xhr.status + ': ' + xhr.statusText
                alert('Error - ' + errorMessage);
            }})


    }





});