$(document).ready(function(){
    /**
     * This function will get all the values in the inputs
     * and will create a valid object to be send to the server-side
     */
    function assembleTour(){
        let tour = {};
        tour.name = $("#name").val();
        tour.location = $("#location").val();
        tour.summary = $("#summary").val();
        tour.description = $("#description").val();
        tour.imageCover= $("#image").val();
        return tour;
    }
    /**
     * This function binds an event to the add button.
     * The idea is that we assemble a valid object from the form
     * and send it to the server-side.
     */
    $("#button-blue").click(function(event){
        event.preventDefault();
        let tour = assembleTour()

        console.log(tour)
        $.ajax({
            url: '/api/v1/tours',
            type: 'POST',
            contentType: 'application/json',
            data: JSON.stringify(tour),
            success: function(response){
                // We can print in the front-end console to verify
                // what is coming back from the server side
                console.log(JSON.stringify(response));
                
            },        
            //We can use the alert box to show if there's an error in the server-side
            error: function(xhr, status, error){
                var errorMessage = xhr.status + ': ' + xhr.statusText
                alert('Error - ' + errorMessage);
            }
        });
    });
});