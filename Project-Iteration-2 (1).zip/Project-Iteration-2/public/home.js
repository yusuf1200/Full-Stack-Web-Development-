$(document).ready(function(){
    
    getAlltours();

    $(".items").on("click", ".item", function(){
        getTour();

    })

    function getAlltours(){
        $.ajax({
            url: '/api/v1/tours',
            type: 'GET',
            contentType: 'application/json',                        
            success: function(response){
                let uid=0;
                
                for(let i = 0; i < response.data.tours.length; i++) {
                    let obj = response.data.tours[i];
                    let name=obj.name;
                    let image=obj.imageCover;
                    let idtour=obj._id;
                    let url="http://localhost:3000/api/v1/tours/"+idtour;
                    let newPage="http://localhost:3000/tourDetails.html"

                    $('.items').append(
                        $('<div>').prop({
                            id: idtour,
                            className: 'item'
                        })
                    );
                    $('#'+idtour).append(`<img id="theImg" src=${image} />`)
                    $('#'+idtour).append(`<p class="ar">${name}</p>`)
                   // $('#'+idtour).append(`<a class="link" href=${newPage}></a>`)
                    

                    uid=uid+1;
    
                }

            },
            // If there's an error, we can use the alert box to make sure we understand the problem
            error: function(xhr, status, error){
                var errorMessage = xhr.status + ': ' + xhr.statusText
                alert('Error - ' + errorMessage);
            }
        });

    }

    function getTour(){
    
        let tourID = $(this).attr('id');
        console.log("Clicked")
        console.log(tourID)
        $.ajax({
            url: '/api/v1/tours/'+tourID,
            type: 'GET',
            contentType: 'application/json',                        
            success: function(response){
                console.log(response)
    
                

            },
            // If there's an error, we can use the alert box to make sure we understand the problem
            error: function(xhr, status, error){
                var errorMessage = xhr.status + ': ' + xhr.statusText
                alert('Error - ' + errorMessage);
            }
        });

    }

});
